# mingzhang-sdd v0.7.0：DSH 插件组合包

在 DSH 的“插件 → 添加”中填入 `mingzhang-sdd-dsh-0.7.0.tgz` 在运行 DSH 机器上的绝对路径。也可填写完整解压目录；根部须同时有 `package.json`、`cordis.patch.yml`、`index.mjs` 和 `SKILL.md`。不要填 WorkBuddy ZIP 或仅含封装的 `adapters/dsh/` 源目录。

```bash
dsh plugin --profile web add /absolute/path/mingzhang-sdd-dsh-0.7.0.tgz
```

组合包名为 `mingzhang-sdd-dsh`，技能名为 `mingzhang-sdd`。按管理器提示重启对应 profile 后，以 `/mingzhang-sdd` 调用。来源 provider 为 `mingzhang-sdd-bundle`；项目／用户同名技能可能优先，需核实际来源。禁用／卸载只管理本组合包，不删除手动安装的同名技能。

## 版本与升级

29份运行文件与指定技能源提交 `c36a9f90405b496a97ab450ad76588cbba07aaca:skills/mingzhang-sdd/` 逐字节一致，为当前文字技能，不包含旧版 scripts 程序资源；另有4份 DSH 封装文件。包版本不表示整包行为验收，原确认仍限各自对象。

v0.4、v0.6.0 与 v0.7.0 使用相同 package name 和 provider id，同一 profile 互斥安装。升级前保留旧 TGZ 作为回退来源，在插件管理器中移除旧组合包，再添加新版；不要同时注册两个解压目录。需要回退时移除新版后重装旧 TGZ。已有手动技能先核来源，避免加载旧副本后误判新版。

## 本地制作

构建明确传入完整技能源提交，从 Git 对象取29份正文，封装取 `adapters/dsh/` 当前字节；`package.json` 的 `mingzhangSdd.sourceCommit` 记录基线。构建过程不运行安装脚本、不联网，输出 `dist/mingzhang-sdd-dsh-v0.7.0/` 与 `dist/mingzhang-sdd-dsh-0.7.0.tgz`，存在即拒绝覆盖。旧 v0.4、v0.6.0 目录与 TGZ 保留。

```bash
node adapters/dsh/build.mjs c36a9f90405b496a97ab450ad76588cbba07aaca
```

验证器仅接受本地 TGZ，安装对象与字节基线为两个独立必填参数。使用完整已安装 DSH 运行库，在临时 profile 离线核对原生管理器及 Loader；不使用现行 profile。结果目录与文件名显式传入，结果存在即拒绝覆盖。

```bash
node adapters/dsh/verify.mjs /absolute/path/to/dsh-runtime /absolute/path/mingzhang-sdd-dsh-0.7.0.tgz results-local-tgz.json /absolute/path/to/new-evidence-directory c36a9f90405b496a97ab450ad76588cbba07aaca
```

本封装使用 Node.js 标准库和 DSH 的技能注册服务，无第三方运行依赖或安装脚本；需要 Node.js 24及宿主提供 `skills`。包格式与加载机制验证不等于网页按钮、模型行为、五工具兼容或真实效果验收。实际结果按该次证据读取，不从本文件推定已经执行。

本次未新增许可证或改变原来源说明。适配实现沿用既有 DSH 注册与组合包机制；本次依据本机运行库核对，未联网重新查阅官方文档。
