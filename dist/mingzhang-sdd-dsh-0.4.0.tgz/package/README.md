# mingzhang-sdd：DSH 插件组合包

这份包用于 DSH 的“插件”添加入口。安装后，它把冻结版 `mingzhang-sdd` 注册为可加载技能，不调用模型、不执行技能中的采集动作，也不复制文件到用户技能目录。28份运行文件保持冻结提交 `9ba51578cc3e56a80f95a49332ba52588ae64bdb` 的字节内容。

## 从插件按钮安装

在运行 DSH 的机器上，进入“插件 → 添加”，将生成的 `mingzhang-sdd-dsh-0.4.0.tgz` 的真实绝对路径填入包地址／安装来源。也可填写解压后的完整包目录；该目录根部应同时含有 `package.json`、`cordis.patch.yml`、`index.mjs` 和 `SKILL.md`。不要填写 WorkBuddy 的 ZIP。

插件显示名称为 `mingzhang-sdd-dsh`，加载的技能仍叫 `mingzhang-sdd`。安装后在会话中用 `/mingzhang-sdd` 调用。若插件管理器提示需要重启，重启对应 DSH profile 后再核对技能是否出现。

等价 CLI（替换 profile 及文件路径）：

```bash
dsh plugin --profile web add /absolute/path/mingzhang-sdd-dsh-0.4.0.tgz
```

通过插件管理器禁用组合包，或禁用 `mingzhang-sdd-skill-provider` 加载项，可以停止本包贡献技能；卸载删除的是该 profile 的包依赖。原先手动安装的同名技能不会随之删除。DSH 的项目／用户同名技能优先于内置包技能，核对最终来源时，本包 provider 为 `mingzhang-sdd-bundle`。

## 制作与边界

源目录 `adapters/dsh/` 只存封装；`build.mjs` 从本制作仓库的冻结提交读取运行文件，输出 `dist/mingzhang-sdd-dsh/`，再用 npm pack 生成安装包。加载入口与 `SKILL.md` 在生成包内同级，不能单独把源目录当成已生成安装包。

本封装使用 Node.js 标准库和 DSH 的 `ctx.skills.registerProvider`，没有第三方运行依赖、安装脚本或构建脚本。它需要运行中的 DSH 提供技能注册表及技能调用能力。包格式与加载机制验证不代表技能模型行为、完整五工具兼容、长期稳定性或真实效果已经验收；既有案例验证范围保持。

本次未新增许可证或修改原有来源说明。适配依据：[DSH 技能注册表](https://github.com/deepseek-ai/deepseek-harness/tree/master/packages/skill/skill)、[组合包机制](https://github.com/deepseek-ai/deepseek-harness/tree/master/packages/bundle)。
